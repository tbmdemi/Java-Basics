public class BankException extends Exception {
    /**
     * Constructor.
     * @param message thong bao loi
     */
    public BankException(String message) {
        super(message);
    }
}
